<?php include('header.php'); ?>
      <section class="slider_area">
         <div id="carouselThree" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#carouselThree" data-slide-to="0" class="active"></li>
               <li data-target="#carouselThree" data-slide-to="1"></li>
               <li data-target="#carouselThree" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="slider-content">
                              <h1 class="title">Business is Now Digital</h1>
                              <p class="text">We blend insights and strategy to create digital products for forward-thinking organisations.</p>
                              <ul class="slider-btn rounded-buttons">
                                 <li><a class="main-btn rounded-one" href="service.php">Learn more</a></li>
                                 <li><a class="main-btn rounded-two" href="contact.php">Get in Touch</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="slider-image-box d-none d-lg-flex align-items-end">
                     <div class="slider-image">
                        <img src="assets/images/slider/1.png" alt="Hero">
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container">
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="slider-content">
                              <h1 class="title">Crafted for Business</h1>
                              <p class="text">We blend insights and strategy to create digital products for forward-thinking organisations.</p>
                              <ul class="slider-btn rounded-buttons">
                                 <li><a class="main-btn rounded-one" href="service.php">Learn more</a></li>
                                 <li><a class="main-btn rounded-two" href="contact.php">Get in touch</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="slider-image-box d-none d-lg-flex align-items-end">
                     <div class="slider-image">
                        <img src="assets/images/slider/2.png" alt="Hero">
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container">
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="slider-content">
                              <h1 class="title">IT Services</h1>
                              <p class="text">We provide outsourced and IT Services for small & Mid-sized Businesses</p>
                              <ul class="slider-btn rounded-buttons">
                                 <li><a class="main-btn rounded-one" href="service.php">Learn more</a></li>
                                 <li><a class="main-btn rounded-two" href="contact.php">Get in touch</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="slider-image-box d-none d-lg-flex align-items-end">
                     <div class="slider-image">
                        <img src="assets/images/slider/3.png" alt="Hero">
                     </div>
                  </div>
               </div>
            </div>
            <a class="carousel-control-prev" href="#carouselThree" role="button" data-slide="prev">
            <i class="lni lni-arrow-left"></i>
            </a>
            <a class="carousel-control-next" href="#carouselThree" role="button" data-slide="next">
            <i class="lni lni-arrow-right"></i>
            </a>
         </div>
      </section>
      <section class="features-area">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-6 col-md-10">
                  <div class="section-title text-center pb-10">
                     <h3 class="title">Our major services</h3>
                     <p class="text">We provide outsourced and IT Services for small & Mid-sized Businesses</p>
                  </div>
               </div>
            </div>
            <div class="row justify-content-center">
               <div class="col-lg-4 col-md-7 col-sm-9">
                  <div class="single-features mt-40">
                     <div class="features-title-icon d-flex justify-content-between">
                        <h4 class="features-title"><a href="#">IT Solutions</a></h4>
                        <div class="features-icon">
                           <i class="lni lni-brush"></i>
                           <img class="shape" src="assets/images/f-shape-1.svg" alt="Shape">
                        </div>
                     </div>
                     <div class="features-content">
                        <p class="text">Whether bringing new amazing products and services to market, or discovering new ways to make mature products.</p>
                        <ul>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> SYSTEM INTEGRATION</a></li>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> DATA CENTRE INFRASTRUCTURE</a></li>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> TELECOMMUNICATIONS</a></li>
                        </ul>

                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-7 col-sm-9">
                  <div class="single-features mt-40">
                     <div class="features-title-icon d-flex justify-content-between">
                        <h4 class="features-title"><a href="#">Managed Security & Services</a></h4>
                        <div class="features-icon">
                           <i class="lni lni-layout"></i>
                           <img class="shape" src="assets/images/f-shape-1.svg" alt="Shape">
                        </div>
                     </div>
                     <div class="features-content">
                        <p class="text">User experience design is the practice of determining how a user will perceive and interact with a product or service.</p>
                        <ul>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> CONSULTATION SERVICES</a></li>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> SYSTEMS AND NETWORKING</a></li>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> SUPPORT SERVICES</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-7 col-sm-9">
                  <div class="single-features mt-40">
                     <div class="features-title-icon d-flex justify-content-between">
                        <h4 class="features-title"><a href="#">IT Services</a></h4>
                        <div class="features-icon">
                           <i class="lni lni-bolt"></i>
                           <img class="shape" src="assets/images/f-shape-1.svg" alt="Shape">
                        </div>
                     </div>
                     <div class="features-content">
                        <p class="text">Big Data analytics software gives businesses new capabilities that were previously only available to governments.</p>
                        <ul>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> MAINTENANCE</a></li>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> OPERATIONS</a></li>
                           <li><a class="features-btn" href="service.php"><i class="lni lni-arrow-right"></i> OUTSOURCING</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="portfolio-area portfolio-four pb-100">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-6 col-md-10">
                  <div class="section-title text-center pb-10">
                     <h3 class="title">Featured Works</h3>
                     <p class="text">Stop wasting time and money designing and managing a website that doesn’t get results. Happiness guaranteed!</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-3 col-md-3">
                  <div class="portfolio-menu text-center mt-50">
                     <ul>
                        <li data-filter="*" class="active">ALL Services</li>
                        <li data-filter=".branding-4">IT Solutions</li>
                        <li data-filter=".marketing-4">Managed Services</li>
                        <li data-filter=".planning-4">IT Services</li>                        
                     </ul>
                  </div>
               </div>
               <div class="col-lg-9 col-md-9">
                  <div class="row no-gutters grid mt-50">
                     <div class="col-lg-4 col-sm-6 branding-4 planning-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/1.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/1.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 marketing-4 research-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/2.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/2.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 branding-4 marketing-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/3.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/3.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 planning-4 research-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/4.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/4.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 marketing-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/5.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/5.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 planning-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/6.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/6.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 research-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/7.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/7.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 branding-4 planning-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/8.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/8.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-sm-6 marketing-4">
                        <div class="single-portfolio">
                           <div class="portfolio-image">
                              <img src="assets/images/portfolio/9.png" alt="">
                              <div class="portfolio-overlay d-flex align-items-center justify-content-center">
                                 <div class="portfolio-content">
                                    <div class="portfolio-icon">
                                       <a class="image-popup" href="assets/images/portfolio/9.png"><i class="lni lni-zoom-in"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                    <div class="portfolio-icon">
                                       <a href="#"><i class="lni lni-link"></i></a>
                                       <img src="assets/images/portfolio/shape.svg" alt="shape" class="shape">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="pricing-area ">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-6 col-md-10">
                  <div class="section-title text-center pb-25">
                     <h3 class="title">WHY CHOOSE US</h3>
                     <p class="text">Few Reasons Why You should Choose Us </p>
                  </div>
               </div>
            </div>
            <div class="row justify-content-center">
               <div class="col-lg-4 col-md-7 col-sm-9">
                  <div class="pricing-style mt-30">
                     <div class="pricing-icon text-center">
                        <img src="assets/images/basic.png" alt="">
                     </div>
                     <div class="pricing-header text-center">
                        <h5 class="sub-title">Cross-Industry Expertise</h5>
                     </div>
                     <div class="pricing-list">
                        <ul>
                           <li><i class="lni lni-check-mark-circle"></i>We have the technology and industry expertise to develop solutions that can connect people and businesses across a variety of mobile devices.</li>                           
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-7 col-sm-9">
                  <div class="pricing-style mt-30">
                     <div class="pricing-icon text-center">
                        <img src="assets/images/pro.png" alt="">
                     </div>
                     <div class="pricing-header text-center">
                        <h5 class="sub-title">Deep Expertise & Leadership</h5>                        
                     </div>
                     <div class="pricing-list">
                        <ul>
                           <li><i class="lni lni-check-mark-circle"></i>We have the technology and industry expertise to develop solutions that can connect people and businesses across a variety of mobile devices.</li>                           
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-7 col-sm-9">
                  <div class="pricing-style mt-30">
                     <div class="pricing-icon text-center">
                        <img src="assets/images/enterprise.png" alt="">                        
                     </div>
                     <div class="pricing-header text-center">
                        <h5 class="sub-title">Dedicated IT Solution </h5>
                     </div>
                     <div class="pricing-list">
                        <ul>
                           <li><i class="lni lni-check-mark-circle"></i> We have the technology and industry expertise to develop solutions that can connect people and businesses across a variety of mobile devices.</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section id="about" class="about-area">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="faq-content mt-45">
                     <div class="about-title">
                        <h6 class="sub-title">WHO WE ARE</h6>
                        <h4 class="title">Custom IT Solutions for You Business</h4>
                     </div>
                     <div class="about-accordion">                                                
                        <h4>We are an advanced change in consultancy franchise and improvement organization.</h4>                                                      
                        <p class="text"><i class="lni lni-arrow-right"></i> Since 2018 we have been a visionary and a reliable IT Solutions & Operations partner for world-class brands. We are a boutique digital transformation consultancy and development company that provides cutting edge engineering solutions.</p>                                                                                                  
                        <a href="service.php" class="link-btn">Learn more  <i class="lni lni-arrow-right"></i></a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-7">
                  <div class="about-image mt-50">
                     <img src="assets/images/about.jpg" alt="about">
                  </div>
               </div>
            </div>
         </div>
      </section>


      <section id="contact" class="contact-area">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <div class="contact-wrapper form-style-two">
                     <h4 class="contact-title pb-10"><i class="lni lni-envelope"></i> Get a Free <span>Consultancy.</span></h4>
                     <form id="contact-form" action="assets/contact.php" method="post">
                        <div class="row">
                           <div class="col-md-6">
                              <div class="form-input mt-25">
                                 <label>Name</label>
                                 <div class="input-items default">
                                    <input name="name" type="text" placeholder="Name">
                                    <i class="lni lni-user"></i>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-input mt-25">
                                 <label>Company</label>
                                 <div class="input-items default">
                                    <input name="name" required type="text" placeholder="Company">
                                    <i class="lni lni-home"></i>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-input mt-25">
                                 <label>Email</label>
                                 <div class="input-items default">
                                    <input type="email" name="email" placeholder="Email">
                                    <i class="lni lni-envelope"></i>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="form-input mt-25">
                                 <label>Subject</label>
                                 <div class="input-items default">
                                    <input type="email" name="email" placeholder="Subject">
                                    <i class="lni lni-list"></i>
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-12">
                              <div class="form-input mt-25">
                                 <label>Massage</label>
                                 <div class="input-items default">
                                    <textarea name="massage" placeholder="Massage"></textarea>
                                    <i class="lni lni-pencil-alt"></i>
                                 </div>
                              </div>
                           </div>
                           <p class="form-message"></p>
                           <div class="col-md-12">
                              <div class="form-input light-rounded-buttons mt-30">
                                 <button class="main-btn light-rounded-two">Free Cousultancy</button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </section>
<?php include('footer.php'); ?>