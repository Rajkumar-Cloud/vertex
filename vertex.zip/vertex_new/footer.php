<section class="footer-area footer-dark">
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-6">
                  <div class="footer-logo text-center">
                     <a class="mt-30" href="index.php"><img src="assets/images/logo.svg" alt="Logo"></a>
                  </div>
                  <!-- <ul class="social text-center mt-60">
                     <li><a href="https://facebook.com/uideckHQ"><i class="lni lni-facebook-filled"></i></a></li>
                     <li><a href="https://twitter.com/uideckHQ"><i class="lni lni-twitter-original"></i></a></li>
                     <li><a href="https://instagram.com/uideckHQ"><i class="lni lni-instagram-original"></i></a></li>
                     <li><a href="#"><i class="lni lni-linkedin-original"></i></a></li>
                  </ul> -->
                  <div class="footer-support text-center">
                     <span class="number">+971 50 5603188</span>
                     <span class="mail"><a href="mailto:info@vertexinfo.ae" class="__cf_email__">info@vertexinfo.ae</a></span>
                  </div>
                  <div class="copyright text-center mt-35">
                     <p class="text">2022 &copy; copyright, all rights recerved by <a href="http://vertexinfo.ae/vertex_feature/" rel="nofollow">Vertex Info System</a> </p>
                  </div>
               </div>
            </div>
         </div>
      </section>
      
      <a href="#" class="back-to-top"><i class="lni lni-chevron-up"></i></a>    
      <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
      <script src="assets/js/popper.min.js"></script>
      <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/slick.min.js"></script>
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <script src="assets/js/ajax-contact.js"></script>
      <script src="assets/js/imagesloaded.pkgd.min.js"></script>
      <script src="assets/js/isotope.pkgd.min.js"></script>
      <script src="assets/js/jquery.easing.min.js"></script>
      <script src="assets/js/scrolling-nav.js"></script>
      <script src="assets/js/main.js"></script>
   </body>
</html>

