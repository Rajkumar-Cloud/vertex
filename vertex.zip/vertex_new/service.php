<?php include('header.php'); ?>
<section class="page-wrapper">
   <div class="header-image">
      <img src="assets/images/services.jpg" alt="images" />
   </div>
</section>

<section class="features-area">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-lg-6 col-md-6">
            <div class="section-title service-head text-center pb-40">
               <h6 class="text-left">OUR SERVICES</h6>
               <h4 class="text text-left">What We Offer for You</h4>
            </div>
         </div>
         <div class="col-lg-6 col-md-6">
            <div class="section-title text-center pb-40">
               <p class="text text-left">Our deep industry expertise enables global brands to hit the ground running.</p>
            </div>
         </div>
      </div>
      <div class="row justify-content-center">
         <div class="col-lg-4 col-md-7 col-sm-9">
            <div class="single-features">
               <div class="features-title-icon d-flex justify-content-between">
                  <h4 class="features-title"><a href="#">IT Solutions</a></h4>
                  <div class="features-icon">
                     <i class="lni lni-brush"></i>
                     <img class="shape" src="assets/images/f-shape-1.svg" alt="Shape">
                  </div>
               </div>
               <div class="features-content">
                  <p class="text">Whether bringing new amazing products and services to market, or discovering new ways to make mature products.</p>
                  <ul>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> SYSTEM INTEGRATION</a></li>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> DATA CENTRE INFRASTRUCTURE</a></li>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> TELECOMMUNICATIONS</a></li>
                  </ul>

               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-7 col-sm-9">
            <div class="single-features">
               <div class="features-title-icon d-flex justify-content-between">
                  <h4 class="features-title"><a href="#">Managed Security &amp; Services</a></h4>
                  <div class="features-icon">
                     <i class="lni lni-layout"></i>
                     <img class="shape" src="assets/images/f-shape-1.svg" alt="Shape">
                  </div>
               </div>
               <div class="features-content">
                  <p class="text">User experience design is the practice of determining how a user will perceive and interact with a product or service.</p>
                  <ul>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> CONSULTATION SERVICES</a></li>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> SYSTEMS AND NETWORKING</a></li>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> SUPPORT SERVICES</a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-7 col-sm-9">
            <div class="single-features">
               <div class="features-title-icon d-flex justify-content-between">
                  <h4 class="features-title"><a href="#">IT Services</a></h4>
                  <div class="features-icon">
                     <i class="lni lni-bolt"></i>
                     <img class="shape" src="assets/images/f-shape-1.svg" alt="Shape">
                  </div>
               </div>
               <div class="features-content">
                  <p class="text">Big Data analytics software gives businesses new capabilities that were previously only available to governments.</p>
                  <ul>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> MAINTENANCE</a></li>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> OPERATIONS</a></li>
                     <li><a class="features-btn" href="#"><i class="lni lni-arrow-right"></i> OUTSOURCING</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>

      <div class="row justify-content-center mt-65">
         <div class="col-lg-9">
            <div class="service-about-title text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.3s; animation-name: fadeInUp;">               
               <h3 class="title"><span>Know </span> More about our services.</h3>
            </div>
         </div>
      </div>

      <div class="row align-items-center">
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/outsource.jpg" alt="">
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">System Integration</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">Vertex offers services in undertaking Information Technology networking systems integration projects in the Emirates and the Gulf Region. We can provide complete and comprehensive systems solutions that fit customer requirements and budget. Through our proven methodologies, we can develop, design, and deploy leading edge, reliable solutions for the IT requirements of our clients in the Emirates and the Gulf Region. We can ensure that our client’s proposed IT infrastructure will be ready today for tomorrow’s applications and business requirements. We have the resources and capability to design, install, configure, and commission and support a broad range of ITC services including but not limited to.</p>
            </div>
         </div>
      </div>

      <div class="row align-items-center">         
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">Data Storage and Security</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">An effective storage solution is a huge contributor to an efficient workday. Dealing with slow response times is a huge contributor to frustration and lost productivity. Building a storage solution that’s efficient for end users and meets the cost pressures of your budget requires some careful planning.</p> 
               <p class="text">Our experts can help analyse your requirements and design a solution that delivers consistent, high performance for your business.</p>
               <p class="text">Our data solutions are bulletproof. Technical excellence is nonnegotiable for us, providing physical security, infrastructure redundancy and operational efficiency within our data center grid. We deliver high availability for mission critical environments, whilst protecting your IP and information. Data security is our number one priority. </p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/data_storage.jpg" alt="">
            </div>
         </div>
      </div>

      <div class="row align-items-center">
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/telecommunication.jpg" alt="">
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">Telecommunication & App. Development</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">Vertex has made its mark not just in the UAE but in the entire Middle East as a leading provider of Telecom solutions.</p>
               <p class="text">The trusted solutions from the company include solutions for Monitoring, Stress Testing, Customer Experience Management (QoE), Roaming & Interconnect, Revenue Assurance, Business Intelligence, OSS/BSS, DMS, Disaster Recovery Automation, GIS and Contact Centers.</p>
               <p class="text">Vertex has extensive experience in creating high performance, feature-packed and digitally transformative native Smartphone applications for all the major mobile platforms including iOS, Android </p>
               <p class="text">We are rapidly expanding our design and development services to leverage applications in Retail, F&B, and Services Industry. Our team is experienced in creating solutions for a wide range of platforms. We offer specialized packages to satisfy a range of needs and budgets, from rapid prototyping for startups to full-featured interfaces for international enterprises.</p>
               <b>Ecommerce Apps</b>
               <p class="text"> We take your e-store to your buyer’s phones with user-friendly e-commerce app.<p>
               <b>Business Apps</b>
               <p class="text">  To optimize your business processes, get an app developed through Creative Solutions.<p>
            </div>
         </div>
      </div>

      <div class="row align-items-center">         
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">Systems and Networking</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">Your office network provides vital connectivity between your computers, phones, servers, wireless access and the outside world.</p> 
               <p class="text">Getting the design and/or implementation of this wrong can have far reaching consequences, resulting in poor performance, loss of internet, Wi-Fi black spots or dropped phone calls.</p>
               <p class="text">The Good IT Company provide a turnkey service, starting with the design of your network, through the installation of cabling, switches and other required hardware and then on to support the installation. When we start a network service, we take ownership of the entire job, meaning you only need to deal with one company for anything network related.</p>
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/system.jpg" alt="">
            </div>
         </div>
      </div>

      <div class="row align-items-center">
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/datacenter.jpg" alt="">
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">Data Center Infrastructure</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">Data center infrastructure refers to the components that make up a data center’s physical infrastructure — networking equipment, storage devices, and switches, to name a few.</p>
               <p class="text">These provide the processing power that organizations need to run their applications and manage their IT operations.</p>
               <p class="text">Data center infrastructure also includes equipment that supports those core components. To keep servers from overheating and shutting down, data centers deploy cooling systems and other environmental controls.</p>               
            </div>
         </div>
      </div>

      <div class="row align-items-center">         
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">Software Solutions</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">Vertex offers business software solution that help organization record micro information with ease.</p> 
               <p class="text">Vertex software division is focused on integrating applications with the existing ERP system of customers to seamlessly monitor staff performance, track telephone usage by the employees, staff login and log-off times, employee details, finances and more in a user-friendly manner. Vertex sincerely works towards improving and uplifting the existing business work process of customers. This mission is fully backed by the highly talented and professional team of engineers and designers who understand the core intentions behind this mission.</p>               
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/soft_solution.jpg" alt="">
            </div>
         </div>
      </div>

      <div class="row align-items-center">
         <div class="col-lg-6">
            <div class="service-about-image mt-50 wow fadeInLeftBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInLeftBig;">
               <img src="assets/images/slider/support.jpg" alt="">
            </div>
         </div>
         <div class="col-lg-6">
            <div class="service-about-content mt-50 wow fadeInRightBig" data-wow-duration="1s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInRightBig;">
               <h3 class="title">Support Services</h3>
               <ul class="about-line">
                  <li></li>
                  <li></li>
                  <li></li>
                  <li></li>
               </ul>
               <p class="text">We offer an extensive range of services, from installation and upgrades to maintenance and emergency repairs. Safety is our number one priority. We work safely and strive to create a safe environment for every client. We never cut corners or take shortcuts. Your satisfaction is our only priority. </p>
               <p class="text">With our fully managed support services, we go beyond the expectations of the average support package. More than just someone on the ground. Alongside support received from our trained onsite support staff, we have a wide-ranging support structure. To ensure that when you need us, we are there 24/7.</p>
            </div>
         </div>
      </div>



   </div>
</section>


<?php include('footer.php'); ?>