<?php
   $active_url = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
      <meta charset="utf-8">
      <title>Vertex</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <link rel="stylesheet" href="assets/css/slick.css">
      <link rel="stylesheet" href="assets/css/LineIcons.css">
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/default.css">
      <link rel="stylesheet" href="assets/css/animate.css">
      <link rel="stylesheet" href="assets/css/style.css">
   </head>
<body>
<div class="preloader">
         <div class="loader">
            <div class="ytp-spinner">
               <div class="ytp-spinner-container">
                  <div class="ytp-spinner-rotator">
                     <div class="ytp-spinner-left">
                        <div class="ytp-spinner-circle"></div>
                     </div>
                     <div class="ytp-spinner-right">
                        <div class="ytp-spinner-circle"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <section class="navbar-area">
         <div class="container">
            <div class="row">
               <div class="col-lg-12">
                  <nav class="navbar navbar-expand-lg">
                     <a class="navbar-brand" href="index.php">
                     <img src="assets/images/logo.svg" alt="Logo">
                     </a>
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTwo" aria-controls="navbarTwo" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="toggler-icon"></span>
                     <span class="toggler-icon"></span>
                     <span class="toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse sub-menu-bar" id="navbarTwo">
                        <ul class="navbar-nav m-auto">
                           <li class="nav-item <?php if($active_url == 'index.php') { echo "active"; } ?>"><a class="page-scroll" href="index.php">home</a></li>                           
                           <li class="nav-item <?php if($active_url == 'aboutus.php') { echo "active"; } ?>"><a class="page-scroll" href="aboutus.php">About</a></li>                           
                           <li class="nav-item <?php if($active_url == 'service.php') { echo "active"; } ?>"><a class="page-scroll" href="service.php">Services</a></li>                         
                           <li class="nav-item <?php if($active_url == 'contact.php') { echo "active"; } ?>"><a class="page-scroll" href="contact.php">Contact</a></li>
                        </ul>
                     </div>
                     <div class="navbar-btn d-none d-sm-inline-block">
                        <ul>
                           <li><a class="solid page-scroll" href="index.php#contact">Free Consultancy</a></li>
                        </ul>
                     </div>
                  </nav>
               </div>
            </div>
         </div>
      </section>