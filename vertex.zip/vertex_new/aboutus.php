<?php include('header.php'); ?>
<section class="slider_area">
   <div class="carousel slide">
      <div class="carousel-inner">
         <div class="carousel-item active">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6">
                     <div class="slider-content">
                        <h1 class="title">About Us</h1>
                        <p class="text">We blend insights and strategy to create digital products for forward-thinking organisations.</p>                        
                     </div>
                  </div>
               </div>
            </div>
            <div class="slider-image-box d-none d-lg-flex align-items-end">
               <div class="slider-image">
                  <img src="assets/images/slider/2.png" alt="Hero">
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-area section-para">
         <div class="container">
            <div class="row">
               <div class="col-lg-5">
                  <div class="faq-content mt-45">
                     <div class="about-title">
                        <h6 class="sub-title">A Little More About Us</h6>
                        <h4 class="title">Keep Your Business Safe & Ensure High Availability</h4>
                     </div>
                     <div class="about-accordion">                                                
                        <h4>Vertex, a 1-Stop full range of systems integration and end to end digital solution, communication and software development solution for SME and larger enterprise. Our skilled engineers are well trained to perform complex integration.</h4>                                                      
                        <p class="text"><i class="lni lni-arrow-right"></i> We are committed to achieve our corporate mission by providing wide range of services and help your company to reduce total cost of ownership. Our innovative and ‘think out-of-box’ DNA brings great value and productivity improvement, adopting Game Change approach for business transformation. Vision.</p>                                                  
                        <p class="text"><i class="lni lni-arrow-right"></i> Transforming our client’s business using our intellectual, game change approach</p>
                        <p class="text"><i class="lni lni-arrow-right"></i> Dependable, Service-Oriented, as your technology partner. Our partnership with suppliers and clients are set to the highest level at all time. We recommend best practices and expert advice to meet your business requirements and growth.</p>
                        <a href="" class="link-btn">Learn more  <i class="lni lni-arrow-right"></i></a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-7">
                  <div class="about-image mt-50">
                     <img src="assets/images/about.jpg" alt="about">
                  </div>
               </div>
            </div>
         </div>
      </section>
<?php include('footer.php'); ?>